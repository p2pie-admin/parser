// exchangerProcessor.ts
import { setData } from "../utils/redis";
import { emoji, mylog } from "../utils/logger.ts";
import RatesParser from "./ParserHandlers/RateParser";
import { IExchanger } from "../types/exchanger";
import { IGeneralData } from "../types/rates";
import { prepareGeneralData } from "./generalDataLoader";

/**
 * Processes one exchanger: skip logic, parsing, logging
 */
export const processSingleExchanger = async (
  exchanger: IExchanger,
  loopsDone: number,
  idx: number
): Promise<void> => {
  try {
    const generalData: IGeneralData = await prepareGeneralData();

    const shouldSkip =
      exchanger.skip && exchanger.skip > 0 && loopsDone % exchanger.skip !== 0;

    if (exchanger.skip && exchanger.skip > 1024) {
      // legacy safeguard - reset skip counter if unreasonably large
      setData(`exchangers:${exchanger.id}:skip`, 0);
    }

    if (shouldSkip && exchanger.skip && !(exchanger.skip < 5)) {
      mylog(
        ` ~ ${emoji(idx)} #${exchanger.id} ${exchanger.name} will skip every ${
          exchanger.skip
        } loops (current loop ${loopsDone})`,
        "warning"
      );
      return;
    }

    const parser = new RatesParser(exchanger, generalData);
    // IMPORTANT: await the main async method — previously it was fire-and-forget
    parser.getExchangerRates();
  } catch (err: any) {
    mylog(
      `processSingleExchanger failed for ${
        exchanger?.id ?? "unknown"
      }: ${String(err?.message ?? err)}`,
      "error"
    );
    // rethrow is optional; caller (withRetry) handles retries
    throw err;
  }
};
