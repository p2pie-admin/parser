import reload from "./reload";
import { IExchanger } from "./types/exchanger";
import { numCPUs, idx, measure } from "./utils/helper";
import { withRetry } from "./utils/internetCheck";
import { emoji, mylog } from "./utils/logger.ts";
import { getData, getObject, setData } from "./utils/redis";
import { processSingleExchanger } from "./rates/exchangerProcessor";
import { splitArrayToNChunks, waitSec } from "./reload/helper";

export const loop = async (): Promise<void> => {
  let loopsDone = 0;

  while (true) {
    const settings = (await getData("parser_setting")) || {};
    // minimum pause = 10 seconds (even if 0 externally)
    const loopPause = Math.max(Number(settings?.pause_between_loops ?? 2), 10);

    const exchangersObj =
      ((await getObject("exchangers")) as { [key: string]: IExchanger }) ?? {};
    const exchangers = Object.values(exchangersObj);
    const chunk = splitArrayToNChunks(exchangers, numCPUs)[idx] || [];
    mylog(`${emoji(idx)} Got ${chunk.length} exchangers`);
    loopsDone % 10 &&
      !idx &&
      setData(
        "stats:chunk_size",
        `На каждое ядро по ~${
          chunk.length
        } обменников. Всего ядер ${numCPUs}. Обменников на одном ядре опрашиваются: ~${
          chunk.filter((e) => !e.skip || e.skip < 5).length
        }, остальные пропускают цикл, так как не дают курсов.`
      );

    const poolLimit = 20;
    const active = new Set<Promise<void>>();

    await measure(
      "loop",
      `${emoji(idx)} Loop ${loopsDone} finished in `,
      async () => {
        for (const exchanger of chunk) {
          // enforce concurrency pool
          if (active.size >= poolLimit) await Promise.race(active);

          const p = (async () => {
            processSingleExchanger(exchanger, loopsDone, idx);
          })().finally(() => active.delete(p));

          active.add(p);
          await waitSec(0.05); // small micro-shift to avoid burst start
        }

        // Wait for all remaining parallel tasks
        await Promise.allSettled(active);
      }
    );

    loopsDone++;
    // During pause, run reload() concurrently if worker 0
    // if (idx === 0) {
    //   mylog(`🔁 Running reload() during ${loopPause}s pause`, "hidden");
    //   try {
    //     // Run reload in parallel with the wait
    //     await Promise.race([
    //       (async () => {
    //         //___________________________________________________________
    //         await reload(loopsDone);
    //         //___________________________________________________________
    //       })(),
    //       waitSec(loopPause), // ensure we wait full pause time anyway
    //     ]);
    //   } catch (err) {
    //     mylog(`⚠️ reload failed: ${String(err)}`, "error");
    //     await waitSec(loopPause); // still wait minimum pause
    //   }
    // } else {
    //   await waitSec(loopPause);
    // }
  }
};
