import { cpus } from "os";
import { mylog } from "./logger.ts";
import { setData } from "./redis";

export const isPrimary = !parseInt(process.env.IDX || "0");
export const idx = parseInt(process.env.IDX || "0");
export const numCPUs = cpus().length;

export async function measure<T>(
  key: string,
  label: string,
  fn: () => Promise<T> | T
): Promise<T> {
  // замеряет время и пишет в stats по ключу key

  const start = performance.now();

  try {
    const result = await fn();
    if (idx) return result;
    const duration = performance.now() - start;

    const formatted =
      duration < 1000
        ? `${duration.toFixed(1)} ms`
        : `${(duration / 1000).toFixed(2)} s`;
    mylog(`---------------------`, "important");
    mylog(`${label} ${formatted}`, "important");
    mylog(`---------------------`, "important");
    setData(`stats:${key}`, `${label} ${formatted}`);
    return result;
  } catch (err: any) {
    const duration = performance.now() - start;
    mylog(`${label} failed after ${duration.toFixed(1)} ms`, "error");
    throw err;
  }
}
