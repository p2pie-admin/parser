import { emoji, mylog } from "../utils/logger.ts";
import { getData, setData } from "../utils/redis";
import statusChange from "../utils/statusChange";

import {
  IErrorCode,
  IExchanger,
  IExchangerParsingError,
  IExchangerParsingInfo,
} from "../types/exchanger";

const errorCodesExplanation = {
  ENOTFOUND: "Соединение не установлено",
  ECONNREFUSED: "По данному IP:PORT ничто не слушает",
  ECONNRESET: "Соединение сорвалось",
  ETIMEDOUT: "Истекло время ожидания",
  ECONNABORTED: "Соединение сорвалось",
  CERT_HAS_EXPIRED: "Сертификат устарел",
  ERR_FR_TOO_MANY_REDIRECTS: "Превышено число перенаправлений",
  EPERM: "Нет разрешения",
  "307": "Соединение перенаправлено",
  "403": "Соединение запрещено",
  "404": "Страница не найдена",
  "500": "Ошибка сервера",
  "503": "Сервер перегружен",
  "522": "Истекло время ожидания",
  unknown: "⦿",
} as { [key in IErrorCode]: string };

export const sendExchangerError = (
  exchanger: IExchanger,
  error?: IExchangerParsingError
) => {
  const idx = parseInt(process.env.IDX || "0");
  if (!error) {
    setData(`exchangers:${exchanger.id}:error`, {});
    return;
  }
  error.codeExplanation = errorCodesExplanation[error.code || "unknown"];
  const { id, name, rates_link } = exchanger;
  mylog(
    ` ˟ ${emoji(idx)} #${id} ${name || ""} : ${
      error.code || error.autoMessage?.substring(0, 50) || ""
    } | ${error.codeExplanation} | ${rates_link}`,
    "error"
  );

  // if (exchanger.status == "active")
  //   statusChange("active", "suspended", exchanger.id);
  setData(`exchangers:${id}:error`, error);
  setData(`exchangers:${id}:skip`, +(exchanger.skip || 1) * 2);
};

export const sendExchangerInfo = (
  exchanger: IExchanger,
  total_rates: number
) => {
  const idx = parseInt(process.env.IDX || "0");
  const { id, name, rates_link } = exchanger;
  mylog(
    ` ✓ ${emoji(idx)} #${id} ${
      name || ""
    } : получено ${total_rates} курсов | ${rates_link}`,
    "success"
  );

  // if (exchanger.status === "suspended")
  //   statusChange("suspended", "active", exchanger.id);
  setData(`exchangers:${id}:total_rates`, total_rates);
  setData(`exchangers:${id}:skip`, 0);
};

export const sendExchangerWarning = async (
  exchangerId: string,
  dir: string,
  message: string
) => {
  setData(`exchangers:${exchangerId}:warnings:${dir}`, message, "main", true);
};
